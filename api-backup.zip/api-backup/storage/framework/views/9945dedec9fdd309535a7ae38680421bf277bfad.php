<?php echo e($slot); ?>

<?php /**PATH /Users/manu/Desktop/ravi-data-new/job-api/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>