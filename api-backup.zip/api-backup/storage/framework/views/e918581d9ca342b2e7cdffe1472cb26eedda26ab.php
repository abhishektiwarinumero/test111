<?php $__env->startComponent('mail::message'); ?>
 <head>
    <title>Welcome Email From StaffManager</title>
  </head>
  <body>
    <h2>Welcome to the StaffManager </h2>
    <br/>
     # Your Verification OPT  <br/>
      your OTP is <?php echo e($token); ?>

   </body>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?> 

<?php /**PATH /Users/manu/Desktop/ravi-data-new/job-api/resources/views/Email/resetPassword.blade.php ENDPATH**/ ?>